"""Shared helpers."""
